"""Shared helpers."""
